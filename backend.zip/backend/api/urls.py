from django.urls import path
from .views import (
    place_cargo,
    retrieve_cargo,
    rearrange_cargo,
    add_waste,
    process_waste,
    get_waste_status,
    simulate_time,
    get_time_status,
    predict_placement,
    predict_waste_type,
)

urlpatterns = [
    path('place-cargo/', place_cargo, name='place-cargo'),
    path('retrieve-cargo/', retrieve_cargo, name='retrieve-cargo'),
    path('rearrange/', rearrange_cargo, name='rearrange-cargo'),
    path('waste/add/', add_waste, name='add-waste'),
    path('waste/process/', process_waste, name='process-waste'),
    path('waste/status/', get_waste_status, name='waste-status'),
    path('simulate-time/', simulate_time, name='simulate-time'),
    path('time/status/', get_time_status, name='time-status'),
    path('predict/placement/', predict_placement, name='predict-placement'),
    path('predict/waste-type/', predict_waste_type, name='predict-waste-type'),
]