from django.db import models

class Cargo(models.Model):
    cargo_type = models.CharField(max_length=100)
    weight = models.FloatField()
    dimensions = models.CharField(max_length=100)
    storage_container = models.CharField(max_length=100)
    coordinates = models.CharField(max_length=50)

    def __str__(self):
        return f"{self.cargo_type} ({self.weight} kg)"

class Waste(models.Model):
    waste_type = models.CharField(max_length=100)
    weight = models.FloatField()
    disposal_date = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.waste_type} ({self.weight} kg)"