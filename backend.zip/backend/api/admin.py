from django.contrib import admin
from .models import Cargo, Waste

admin.site.register(Cargo)
admin.site.register(Waste)