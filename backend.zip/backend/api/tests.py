from django.urls import reverse
from rest_framework import status
from rest_framework.test import APITestCase
from .models import Cargo, Waste
from .serializers import CargoSerializer, WasteSerializer

class CargoAPITests(APITestCase):
    def setUp(self):
        self.cargo_data = {
            'type': 'Food',
            'weight': 100,
            'dimensions': '10x10x10'
        }
        self.waste_data = {
            'type': 'Organic',
            'weight': 50
        }
        self.cargo = Cargo.objects.create(**self.cargo_data)
        self.waste = Waste.objects.create(**self.waste_data)

    def test_create_cargo(self):
        response = self.client.post(reverse('cargo-list'), self.cargo_data, format='json')
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(Cargo.objects.count(), 2)

    def test_retrieve_cargo(self):
        response = self.client.get(reverse('cargo-detail', args=[self.cargo.id]), format='json')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data, CargoSerializer(self.cargo).data)

    def test_retrieve_nonexistent_cargo(self):
        response = self.client.get(reverse('cargo-detail', args=[999]), format='json')
        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)

    def test_create_waste(self):
        response = self.client.post(reverse('waste-list'), self.waste_data, format='json')
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(Waste.objects.count(), 2)

    def test_retrieve_waste(self):
        response = self.client.get(reverse('waste-detail', args=[self.waste.id]), format='json')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data, WasteSerializer(self.waste).data)

    def test_retrieve_nonexistent_waste(self):
        response = self.client.get(reverse('waste-detail', args=[999]), format='json')
        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)