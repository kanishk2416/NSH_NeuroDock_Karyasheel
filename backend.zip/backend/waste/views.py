from rest_framework import viewsets
from rest_framework.response import Response
from .models import Waste
from .serializers import WasteSerializer

class WasteViewSet(viewsets.ViewSet):
    def create(self, request):
        serializer = WasteSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=201)
        return Response(serializer.errors, status=400)

    def process(self, request):
        # Logic for waste segregation would go here
        return Response({"message": "Waste processed"}, status=200)

    def list(self, request):
        queryset = Waste.objects.all()
        serializer = WasteSerializer(queryset, many=True)
        return Response(serializer.data)

    def retrieve(self, request, pk=None):
        try:
            waste = Waste.objects.get(pk=pk)
            serializer = WasteSerializer(waste)
            return Response(serializer.data)
        except Waste.DoesNotExist:
            return Response({"error": "Waste not found"}, status=404)