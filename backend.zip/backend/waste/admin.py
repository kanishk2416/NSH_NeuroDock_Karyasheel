from django.contrib import admin
from .models import Waste

admin.site.register(Waste)