from django.test import TestCase
from .models import Waste

class WasteModelTests(TestCase):

    def setUp(self):
        Waste.objects.create(type="Organic", weight=5.0)
        Waste.objects.create(type="Plastic", weight=2.0)

    def test_waste_creation(self):
        """Test if waste is created correctly."""
        organic_waste = Waste.objects.get(type="Organic")
        plastic_waste = Waste.objects.get(type="Plastic")
        self.assertEqual(organic_waste.weight, 5.0)
        self.assertEqual(plastic_waste.weight, 2.0)

    def test_waste_str(self):
        """Test the string representation of the Waste model."""
        waste = Waste.objects.get(type="Organic")
        self.assertEqual(str(waste), "Organic Waste - 5.0 kg")

    def test_waste_weight(self):
        """Test if the weight of waste is stored correctly."""
        waste = Waste.objects.get(type="Plastic")
        self.assertEqual(waste.weight, 2.0)