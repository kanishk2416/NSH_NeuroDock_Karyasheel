from django.db import transaction
from .models import Waste
from .serializers import WasteSerializer

class WasteService:
    @staticmethod
    @transaction.atomic
    def add_waste(data):
        serializer = WasteSerializer(data=data)
        if serializer.is_valid():
            waste = serializer.save()
            return waste
        else:
            raise ValueError("Invalid waste data")

    @staticmethod
    def process_waste(waste_id):
        try:
            waste = Waste.objects.get(id=waste_id)
            waste.processed = True
            waste.save()
            return waste
        except Waste.DoesNotExist:
            raise ValueError("Waste not found")

    @staticmethod
    def get_waste_status():
        return Waste.objects.all()