from django.db import models

class Container(models.Model):
    container_id = models.CharField(max_length=50, unique=True)
    capacity = models.FloatField()
    current_weight = models.FloatField(default=0)
    location_x = models.IntegerField()
    location_y = models.IntegerField()
    location_z = models.IntegerField()
    is_active = models.BooleanField(default=True)

class Cargo(models.Model):
    cargo_id = models.CharField(max_length=50, unique=True)
    container = models.ForeignKey(Container, on_delete=models.CASCADE)
    weight = models.FloatField()
    dimensions = models.JSONField()  # Store length, width, height
    cargo_type = models.CharField(max_length=50)
    date_added = models.DateTimeField(auto_now_add=True)
    is_waste = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.cargo_type} ({self.weight} kg)"

class Waste(models.Model):
    waste_type = models.CharField(max_length=100)
    weight = models.FloatField()
    disposal_date = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.waste_type} ({self.weight} kg)"