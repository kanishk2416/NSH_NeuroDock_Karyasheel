from django.db import transaction
from .models import Cargo, Waste
from .serializers import CargoSerializer, WasteSerializer

class CargoService:
    @staticmethod
    @transaction.atomic
    def place_cargo(cargo_data):
        cargo = Cargo(**cargo_data)
        cargo.save()
        return CargoSerializer(cargo).data

    @staticmethod
    def retrieve_cargo(cargo_id):
        try:
            cargo = Cargo.objects.get(id=cargo_id)
            return CargoSerializer(cargo).data
        except Cargo.DoesNotExist:
            return None

    @staticmethod
    @transaction.atomic
    def rearrange_cargo(cargo_id, new_position):
        try:
            cargo = Cargo.objects.get(id=cargo_id)
            cargo.position = new_position
            cargo.save()
            return CargoSerializer(cargo).data
        except Cargo.DoesNotExist:
            return None

class WasteService:
    @staticmethod
    @transaction.atomic
    def add_waste(waste_data):
        waste = Waste(**waste_data)
        waste.save()
        return WasteSerializer(waste).data

    @staticmethod
    def process_waste(waste_id):
        try:
            waste = Waste.objects.get(id=waste_id)
            waste.processed = True
            waste.save()
            return WasteSerializer(waste).data
        except Waste.DoesNotExist:
            return None

    @staticmethod
    def get_waste_status():
        return WasteSerializer(Waste.objects.all(), many=True).data