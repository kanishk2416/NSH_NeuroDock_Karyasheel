from rest_framework import viewsets
from rest_framework.response import Response
from rest_framework.decorators import action
from .models import Container, Cargo
from .serializers import ContainerSerializer, CargoSerializer

class CargoViewSet(viewsets.ModelViewSet):
    queryset = Cargo.objects.all()
    serializer_class = CargoSerializer

    @action(detail=False, methods=['post'])
    def place_cargo(self, request):
        # Add cargo placement logic here
        serializer = self.get_serializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=201)
        return Response(serializer.errors, status=400)

    @action(detail=True, methods=['post'])
    def retrieve_cargo(self, request, pk=None):
        try:
            cargo = self.get_object()
            # Add retrieval logic here
            return Response({"message": f"Cargo {cargo.cargo_id} retrieved"})
        except Cargo.DoesNotExist:
            return Response({"error": "Cargo not found"}, status=404)

class ContainerViewSet(viewsets.ModelViewSet):
    queryset = Container.objects.all()
    serializer_class = ContainerSerializer