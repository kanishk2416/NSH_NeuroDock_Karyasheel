from django.test import TestCase
from .models import Cargo

class CargoModelTests(TestCase):

    def setUp(self):
        Cargo.objects.create(type="Food", weight=10, dimensions="10x10x10")
        Cargo.objects.create(type="Equipment", weight=20, dimensions="20x20x20")

    def test_cargo_creation(self):
        """Test if cargo is created successfully."""
        cargo = Cargo.objects.get(type="Food")
        self.assertEqual(cargo.weight, 10)
        self.assertEqual(cargo.dimensions, "10x10x10")

    def test_cargo_retrieval(self):
        """Test if cargo can be retrieved by type."""
        cargo = Cargo.objects.get(type="Equipment")
        self.assertEqual(cargo.weight, 20)

    def test_cargo_weight_limit(self):
        """Test if weight limit is enforced."""
        with self.assertRaises(ValueError):
            Cargo.objects.create(type="Heavy Equipment", weight=1000, dimensions="50x50x50")  # Assuming a weight limit is set in the model

    def test_cargo_str(self):
        """Test the string representation of the cargo."""
        cargo = Cargo.objects.get(type="Food")
        self.assertEqual(str(cargo), "Food")  # Assuming the __str__ method returns the type of cargo