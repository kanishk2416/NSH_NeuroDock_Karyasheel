from django.contrib import admin
from .models import Cargo

admin.site.register(Cargo)