from django.test import TestCase
from .services import SimulationService

class SimulationServiceTests(TestCase):
    
    def setUp(self):
        self.simulation_service = SimulationService()

    def test_time_advance(self):
        initial_time = self.simulation_service.get_current_time()
        self.simulation_service.advance_time(5)  # Advance time by 5 units
        new_time = self.simulation_service.get_current_time()
        self.assertEqual(new_time, initial_time + 5)

    def test_cargo_rearrangement(self):
        # Assuming we have a method to add cargo and rearrange it
        self.simulation_service.add_cargo(cargo_id=1, weight=10)
        self.simulation_service.add_cargo(cargo_id=2, weight=20)
        rearranged = self.simulation_service.rearrange_cargo()
        self.assertTrue(rearranged)

    def test_waste_management(self):
        self.simulation_service.add_waste(waste_id=1, type='organic')
        waste_status = self.simulation_service.get_waste_status()
        self.assertIn('organic', waste_status)

    def test_simulation_run(self):
        result = self.simulation_service.run_simulation(duration=10)
        self.assertTrue(result['success'])
        self.assertGreater(result['final_state'], 0)  # Assuming final_state is a metric of success

    def test_prediction_model(self):
        placement = self.simulation_service.predict_cargo_placement(cargo_id=1)
        self.assertIsNotNone(placement)  # Ensure a placement suggestion is returned