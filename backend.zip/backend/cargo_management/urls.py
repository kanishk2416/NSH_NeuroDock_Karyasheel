from django.urls import path
from api import views as api_views

urlpatterns = [
    path('api/place-cargo/', api_views.place_cargo, name='place_cargo'),
    path('api/retrieve-cargo/', api_views.retrieve_cargo, name='retrieve_cargo'),
    path('api/rearrange/', api_views.rearrange_cargo, name='rearrange_cargo'),
    path('api/containers/', api_views.get_container_status, name='get_container_status'),
    path('api/waste/add/', api_views.add_waste, name='add_waste'),
    path('api/waste/process/', api_views.process_waste, name='process_waste'),
    path('api/waste/status/', api_views.get_waste_status, name='get_waste_status'),
    path('api/simulate-time/', api_views.simulate_time, name='simulate_time'),
    path('api/time/status/', api_views.get_time_status, name='get_time_status'),
    path('api/predict/placement/', api_views.predict_placement, name='predict_placement'),
    path('api/predict/waste-type/', api_views.predict_waste_type, name='predict_waste_type'),
]