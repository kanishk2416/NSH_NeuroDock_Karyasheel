from rest_framework import viewsets
from rest_framework.response import Response
from .models.placement_model import PlacementModel
from .models.waste_classifier import WasteClassifier
from .serializers import PlacementSerializer, WasteClassifierSerializer

class PlacementViewSet(viewsets.ViewSet):
    def create(self, request):
        serializer = PlacementSerializer(data=request.data)
        if serializer.is_valid():
            # Logic to handle placement prediction
            placement_data = serializer.validated_data
            prediction = PlacementModel.predict(placement_data)
            return Response({'prediction': prediction}, status=201)
        return Response(serializer.errors, status=400)

class WasteClassifierViewSet(viewsets.ViewSet):
    def create(self, request):
        serializer = WasteClassifierSerializer(data=request.data)
        if serializer.is_valid():
            # Logic to classify waste
            waste_data = serializer.validated_data
            classification = WasteClassifier.classify(waste_data)
            return Response({'classification': classification}, status=201)
        return Response(serializer.errors, status=400)