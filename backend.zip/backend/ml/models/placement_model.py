from sklearn.ensemble import RandomForestRegressor
import numpy as np
import joblib

class PlacementModel:
    def __init__(self):
        self.model = RandomForestRegressor()
        self.is_trained = False

    def train(self, X, y):
        self.model.fit(X, y)
        self.is_trained = True

    def predict(self, cargo_features):
        if not self.is_trained:
            raise Exception("Model is not trained yet.")
        return self.model.predict(np.array(cargo_features).reshape(1, -1))

    def save_model(self, file_path):
        joblib.dump(self.model, file_path)

    def load_model(self, file_path):
        self.model = joblib.load(file_path)
        self.is_trained = True
