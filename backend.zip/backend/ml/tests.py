from django.test import TestCase
from ..models.placement_model import PlacementModel
from ..models.waste_classifier import WasteClassifier

class MLModelTests(TestCase):

    def setUp(self):
        # Set up any necessary data for the tests
        self.placement_model = PlacementModel()
        self.waste_classifier = WasteClassifier()

    def test_placement_prediction(self):
        # Test the placement prediction functionality
        cargo_data = {
            'type': 'food',
            'weight': 10,
            'dimensions': (2, 2, 2)
        }
        predicted_container = self.placement_model.predict(cargo_data)
        self.assertIsNotNone(predicted_container)

    def test_waste_classification(self):
        # Test the waste classification functionality
        waste_data = {
            'type': 'organic',
            'weight': 5,
            'dimensions': (1, 1, 1)
        }
        classified_waste = self.waste_classifier.classify(waste_data)
        self.assertIn(classified_waste, ['organic', 'recyclable', 'non-recyclable'])